DIGITAL SHIELD - START HERE
==========================

Project contents
----------------
frontend/  Static HTML, CSS and JavaScript website (deploy this folder to Netlify)
backend/   PHP API and Dockerfile (deploy this on AWS EC2 using Docker)
docker-compose.yml  Runs the PHP backend on port 8080

IMPORTANT
---------
This is a clean starter/recreated version based on the Digital Shield interface visible
in the screenshots you supplied. The security response uses a SAMPLE rule only.
It is not connected to JazzCash/Easypaisa and does not detect real fraud.

STEP 1 - TEST FRONTEND
----------------------
Open frontend/index.html in your browser, or use VS Code Live Server.

STEP 2 - TEST BACKEND LOCALLY WITH DOCKER
-----------------------------------------
Install Docker Desktop and start it.
Open a terminal in the extracted Digital_Shield_Project folder.
Run:
  docker compose up --build -d
Then open:
  http://localhost:8080
The API health response should appear.
The POST endpoint is:
  http://localhost:8080/api/check.php

STEP 3 - CONNECT FRONTEND TO BACKEND
------------------------------------
After deploying the backend to EC2, open frontend/script.js.
Replace:
  http://YOUR_EC2_PUBLIC_IP:8080/api/check.php
with your actual public EC2 URL, for example:
  http://YOUR_REAL_EC2_IP:8080/api/check.php
Save the file and redeploy the frontend folder to Netlify.

STEP 4 - NETLIFY FRONTEND
-------------------------
Log in to Netlify. Choose Add new site / Deploy manually (or import the Git repository).
For a manual deploy, drag the frontend folder contents into the deploy area.
Copy the real public URL Netlify gives you.

STEP 5 - AWS EC2 BACKEND
------------------------
Launch an Ubuntu EC2 instance. Create/choose a key pair and download the .pem file.
In the EC2 Security Group, allow SSH (TCP 22) from My IP and Custom TCP 8080 from
0.0.0.0/0 for this classroom demonstration. Do not expose SSH to everyone.
Connect to the instance using the AWS browser SSH or your local SSH client.
Install Docker using the current official Docker Engine instructions for Ubuntu.
Transfer this project folder to EC2 (SCP/SFTP), then run from the project directory:
  sudo docker compose up --build -d
Test:
  http://YOUR_EC2_PUBLIC_IP:8080
and:
  http://YOUR_EC2_PUBLIC_IP:8080/api/check.php
The API endpoint expects a POST request, so opening it in a browser may show a method
message; that is normal.

SECURITY / ACCURACY NOTES
------------------------
- Never upload your .pem private key to GitHub or include it in the submission PDF.
- Replace the frontend API URL only with your own real EC2 public IP.
- HTTP is used for the classroom demo. For a real public service, configure HTTPS.
- Keep your EC2 instance running for the live URL to remain available; AWS charges may apply.
- Capture your own screenshots as you complete each step.
