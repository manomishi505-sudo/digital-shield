<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") { http_response_code(204); exit; }
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode(["message" => "Use POST to submit a wallet number."]);
    exit;
}

$input = json_decode(file_get_contents("php://input"), true);
$wallet = isset($input["wallet_number"]) ? trim($input["wallet_number"]) : "";
$digits = preg_replace("/\D+/", "", $wallet);

if (strlen($digits) < 10 || strlen($digits) > 15) {
    http_response_code(422);
    echo json_encode(["message" => "Please provide a wallet number containing 10 to 15 digits."]);
    exit;
}

// Educational demonstration only: this deterministic sample rule is NOT real fraud detection.
$lastDigit = (int) substr($digits, -1);
if ($lastDigit % 2 === 0) {
    $status = "Normal";
    $message = "No sample rule was triggered for this wallet number.";
} else {
    $status = "Attention Required";
    $message = "A sample review rule was triggered. Further human review would be required.";
}

echo json_encode([
    "status" => $status,
    "message" => $message,
    "reference" => "DS-" . strtoupper(substr(hash("sha256", $digits), 0, 8)),
    "notice" => "Demonstration response only; not a real financial risk assessment."
]);
