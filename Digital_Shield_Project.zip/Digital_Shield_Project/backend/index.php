<?php
header("Content-Type: application/json; charset=UTF-8");
echo json_encode([
  "service" => "Digital Shield API",
  "status" => "running",
  "endpoint" => "/api/check.php",
  "method" => "POST"
]);
