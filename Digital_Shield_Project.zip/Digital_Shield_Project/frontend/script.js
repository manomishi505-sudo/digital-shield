// Set this to your public AWS backend URL after deploying the PHP API.
const API_URL = "http://YOUR_EC2_PUBLIC_IP:8080/api/check.php";

const form = document.getElementById("checkForm");
const result = document.getElementById("result");
const button = document.getElementById("verifyBtn");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const wallet = document.getElementById("wallet").value.trim();
  if (!/^[0-9+\-\s]{10,15}$/.test(wallet)) {
    result.innerHTML = '<div class="result-box error">Please enter a valid mobile wallet number (10–15 digits).</div>';
    return;
  }

  button.disabled = true;
  button.textContent = "Checking...";
  result.textContent = "";

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ wallet_number: wallet })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "The security service could not process the request.");
    const warning = data.status === "Attention Required";
    result.innerHTML = `<div class="result-box ${warning ? "warning" : ""}"><strong>${data.status}</strong><br>${data.message}<br><small>Reference: ${data.reference}</small></div>`;
  } catch (error) {
    result.innerHTML = `<div class="result-box error">${error.message}. Confirm that the backend URL is configured and the AWS container is running.</div>`;
  } finally {
    button.disabled = false;
    button.innerHTML = 'Verify security <span>→</span>';
  }
});
